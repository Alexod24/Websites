<!-- Start Facts-->
<section id="facts" class="section parallax">
    <div class="overlay"></div>
       <div class="container">
           <div class="row">
                  
                <!-- Start Item-->
                <div class="col-md-3 col-sm-6 facts-box margin-bottom-30">
                    <span><i class='bx bx-happy-alt'></i></span>
                    <h3>841</h3>
                    <span>Clientes felices</span>
                </div>
                <!-- End Item-->
 
                 <!-- Start Item-->
                <div class="col-md-3 col-sm-6 facts-box margin-bottom-30">
                 <span><i class='bx bx-briefcase-alt-2'></i></span>
                    <h3>800</h3>
                    <span>Casos</span>
                </div>
                <!-- End Item-->

                 <!-- Start Item-->
                <div class="col-md-3 col-sm-6 facts-box margin-bottom-30">
                 <span><i class='bx bxs-user-check'></i></span>
                    <h3>1232</h3>
                    <span>Casos resueltos</span>
                </div>
                <!-- End Item-->

                 <!-- Start Item-->
                <div class="col-md-3 col-sm-6 facts-box margin-bottom-30">
                 <span><i class='bx bx-like'></i></span>
                    <h3>300</h3>
                    <span>Concilaciones</span>
                </div>
                <!-- End Item-->

             </div> <!-- /.row -->
       </div> <!-- /.container -->
  </section>
  <!--End Facts-->